import { useEffect, useState, useRef } from "react";

function App() {
  const [logs, setLogs] = useState([]);
  const [input, setInput] = useState("");
  const [modo, setModo] = useState(null); // "pass", "usuario", null
  const bottomRef = useRef(null);


  useEffect(() => {
    const ws = new WebSocket("ws://localhost:8080");

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      const mensaje = data.message.trim();
      setLogs((prev) => [...prev, mensaje]);

      if (mensaje.includes("Introduce contraseña admin")) {
          setModo("pass");
        } else if (mensaje.includes("Ingresa nombre de usuario")) {
          setModo("usuario");
        } else if (
          mensaje.includes("Contraseña incorrecta") ||
          mensaje.includes("Usuario agregado correctamente.") ||
          mensaje.includes("No hay espacio")
        ) {
          setModo(null);
        }
      };
      

    return () => ws.close();
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);


  const enviar = async () => {
    if (!input.trim()) return;
    await fetch("http://localhost:3001/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mensaje: input }),
    });
      setLogs((prev) => [...prev, "> " + input]);
      setInput("");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2 className="text-xl">Salida Serial ESP32</h2>
      <div className="bg-gray-900 text-gray-100 w-full h-80 overflow-y-auto">
        {logs.map((linea, i) => (
          <div key={i}>{linea}</div>
        ))}
        <div ref={bottomRef} />
      </div>

      {modo === "pass" && <h3>Ingrese contraseña admin:</h3>}
      {modo === "usuario" && <h3>Ingrese nombre de usuario:</h3>}

      <div style={{ marginTop: 10 }}>
      <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={
            modo === "pass"
              ? "Contraseña admin"
              : modo === "usuario"
              ? "Nombre de usuario"
              : "Escribir comando"
          }
        />
        <button className="border rounded-lg w-20 p-1 hover:bg-gray-300" onClick={enviar}>
          Enviar
        </button>
      </div>

    </div>
  );
}

export default App;