public class MiChar {
    char c;

    public MiChar(char c) {
        this.c = c;
    }

    public char get() {
        return c;
    }
}
