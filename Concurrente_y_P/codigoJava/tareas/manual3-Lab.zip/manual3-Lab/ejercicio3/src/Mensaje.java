public class Mensaje {
    public String id;
    public int dato;

    public Mensaje() {
        id = "";
        dato = 0;
    }

    public Mensaje(String id, int dato) {
        this.id = id;
        this.dato = dato;
    }
}